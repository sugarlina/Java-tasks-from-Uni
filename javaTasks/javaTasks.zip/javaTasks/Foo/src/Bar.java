public class Bar extends Foo {
    public void method2() {
        System.out.println("bar 2");
    }
}
