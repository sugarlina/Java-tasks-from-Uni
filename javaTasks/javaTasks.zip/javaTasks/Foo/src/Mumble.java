public class Mumble extends Baz {
    public void method2() {
        System.out.println("mumble2");
    }
}
